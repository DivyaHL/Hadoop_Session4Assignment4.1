package main.java;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.plaf.nimbus.NimbusLookAndFeel;

import org.omg.CORBA._PolicyStub;

public class Acad8 {
	public static void main(String[] args) {
		int[] numbers = {10,20,3,4,50,89};
		System.out.println("before sorting in desc order:"+Arrays.toString(numbers));
		Acad8 obj = new Acad8();
		int[] orderdNumbers = obj.getSortArrayDesc(numbers);
		int[] _orderdNumbers = new int[orderdNumbers.length];
		int j = 0;
		for (int i = orderdNumbers.length-1; i >=0; i--){
			_orderdNumbers[j++] = orderdNumbers[i];
		}
		System.out.println("after sorting in desc order:"+Arrays.toString(_orderdNumbers));
	}
	
	public int[] getSortArrayDesc(int[] numbers) {
		int[] orderNumbers = new int[numbers.length];
		for (int i = 0; i < numbers.length; i++){
			int index = 0;
			for (int j = 0; j < numbers.length; j++){
				if  (numbers[i] > numbers[j]){
					index++;
				}
			}
			orderNumbers[index] = numbers[i];
		}
		return orderNumbers;
	}
}
