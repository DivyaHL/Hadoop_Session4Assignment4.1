package main.java;

public class Acad {
	public static void main(String[] args) {
		int a =1;
		int b=2;
		int sum =a+b;
		System.out.println("sum of a and b ="+sum);
	}

}
