package main.java;

public class Acad6 {
	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		int z = 30;
		Acad6 obj = new Acad6();
		obj.sum(x, y);
		obj.sum(x, y, z);
	}
	public void sum(int x, int y) {
		System.out.println("sum method with 2 arguments "+x+" and "+y);
		System.out.println("sum is:"+(x+y));
	}
	 public void sum(int x, int y, int z) {
		System.out.println("overloaded sum method with 3 arguments "+x+", "+y+" and "+z);
		System.out.println("sum is:"+(x+y+z));
	}
}
