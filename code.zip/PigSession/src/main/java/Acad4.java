package main.java;

import java.util.ArrayList;
import java.util.Arrays;

public class Acad4 {


	public static void main(String[] args) {
		if (args.length > 0){
			int x = Integer.valueOf(args[0]);
			int y = Integer.valueOf(args[1]);
			@SuppressWarnings("unchecked")
			ArrayList<Integer> even = new ArrayList();
			@SuppressWarnings("rawtypes")
			ArrayList<Integer> odd = new ArrayList();
			for (int i = x; i <= y; i++){
				if (i%2 == 0){
					even.add(i);
				} else {
					odd.add(i);
				}
			}
			System.out.println("even numbers = "+ even.toString());
			System.out.println("odd numbers = "+odd.toString());
		} else {
			System.out.println("please enter the inputs @ stdin");
		}

	}
}
