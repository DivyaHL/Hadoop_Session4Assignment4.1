package main.java;

import javax.xml.crypto.dsig.keyinfo.RetrievalMethod;

public class Acad7 {
	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		int z = 30;
		Acad7 obj = new Acad7();
		int res = obj.sum(x, y);
		System.out.println("sum is:"+res);
		res = obj.sum(x, y, z);
		System.out.println("sum is:"+res);
	}
	public int sum(int x, int y) {
		System.out.println("sum method with 2 arguments "+x+" and "+y);
		return x+y;
	}
	 public int sum(int x, int y, int z) {
		System.out.println("overloaded sum method with 3 arguments "+x+", "+y+" and "+z);
		return x+y+z;
	}
}
