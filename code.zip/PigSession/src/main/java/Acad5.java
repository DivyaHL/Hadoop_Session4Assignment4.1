package main.java;

import java.io.ObjectInputStream.GetField;

public class Acad5 {
	
	public static void main(String[] args) {
		int number = Integer.valueOf(args[0]);
		System.err.println("Table for Number:"+number);
		Acad5 obj = new Acad5();
		obj.getPrintTable(number);
	}

	public void getPrintTable(int number) {
		for (int i  = 1; i <= 10; i++){
			System.out.println(number+" X "+i+" = "+(number*i));
			System.out.println("");
		}
	}
}
