package main.java;

public class Acad2 {
	public static void main(String[] args) {
		Acad2 obj = new Acad2();
		int res = obj.sum(10, 20);
		System.out.println("Sum is:"+res);
	}
	
	public int sum(int x, int y) {
		System.out.println("First number is:"+x);
		System.out.println("Second number is:"+y);
		return x+y;
	}
}
